package tanks;
public enum GameState {

    WINNER_FOUND,
    GAME_IS_ON,
    GAME_FINISHED_AHEAD_OF_SCHEDULE
}
