package tanks;
public class Wall extends GameObject {

    @Override
    public void setDestructibility(boolean destructibility) {
        super.setDestructibility(destructibility);
    }

    @Override
    public boolean getDestructibility() {
        return super.getDestructibility();
    }

    @Override
    public Cell getPosition() {
        return super.getPosition();
    }

    @Override
    public void setPosition(Cell position) {
        super.setPosition(position);
    }
}
